const ownerWhatsApp = "967770304947";

const packages = [
  {name:"أبو 100", price:100, data:"300 ميجا"},
  {name:"أبو 200", price:200, data:"700 ميجا"},
  {name:"أبو 300", price:300, data:"1 جيجا"},
  {name:"أبو 500", price:500, data:"2 جيجا"},
  {name:"أبو 1000", price:1000, data:"4 جيجا"},
  {name:"أبو 2000", price:2000, data:"8 جيجا"},
  {name:"أبو 2500", price:2500, data:"10 جيجا"}
];

const wallets = [
  {name:"Jaib", api:"ضع رابط API هنا"},
  {name:"Jawali", api:"ضع رابط API هنا"},
  {name:"ONE Cash", api:"ضع رابط API هنا"},
  {name:"Floosak", api:"ضع رابط API هنا"},
  {name:"Mobile Money", api:"ضع رابط API هنا"},
  {name:"Mahfathati", api:"ضع رابط API هنا"}
];

const stores = [
  {name:"البقالة المركزية", area:"الحي الرئيسي", map:"https://maps.google.com"},
  {name:"مركز الاتصالات", area:"جوار السوق", map:"https://maps.google.com"},
  {name:"وكيل الشبكة", area:"قريب من المسجد", map:"https://maps.google.com"}
];

let selectedPackage = packages[0];
let selectedSpeed = "ضعيف";

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(tab.dataset.page).classList.add("active");
  });
});

document.querySelectorAll(".speed").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".speed").forEach(s => s.classList.remove("active"));
    btn.classList.add("active");
    selectedSpeed = btn.dataset.speed;
  });
});

function renderPackages(){
  const wrap = document.getElementById("packages");
  wrap.innerHTML = "";
  packages.forEach((p, index) => {
    const div = document.createElement("div");
    div.className = "package" + (index === 0 ? " active" : "");
    div.innerHTML = `<strong>${p.name}</strong><span>${p.data}</span><br><small>${p.price} ريال</small>`;
    div.onclick = () => {
      selectedPackage = p;
      document.querySelectorAll(".package").forEach(x => x.classList.remove("active"));
      div.classList.add("active");
    };
    wrap.appendChild(div);
  });

  const contest = document.getElementById("contestPackage");
  contest.innerHTML = packages.map(p => `<option value="${p.price}">${p.name} - ${p.data}</option>`).join("");

  const largest = packages[packages.length - 1];
  document.getElementById("largestPackageLabel").textContent = `${largest.name} - ${largest.data}`;
}

function renderWallets(){
  const wrap = document.getElementById("walletList");
  wrap.innerHTML = wallets.map(w => `
    <div class="wallet">
      <h3>${w.name}</h3>
      <small>API: ${w.api}</small>
    </div>
  `).join("");
}

function renderStores(){
  const wrap = document.getElementById("storeList");
  wrap.innerHTML = stores.map(s => `
    <div class="store">
      <h3>${s.name}</h3>
      <p>${s.area}</p>
      <a href="${s.map}" target="_blank">فتح الموقع على Google Maps</a>
    </div>
  `).join("");
}

function loginCard(){
  const card = document.getElementById("cardInput").value.trim();
  document.getElementById("passwordInput").value = card;
  return true;
}

function orderSelectedPackage(){
  const msg = `السلام عليكم، أريد طلب كرت شبكة:
الباقة: ${selectedPackage.name}
الحجم: ${selectedPackage.data}
السعر: ${selectedPackage.price} ريال
السرعة المطلوبة: ${selectedSpeed}`;
  window.open(`https://wa.me/${ownerWhatsApp}?text=${encodeURIComponent(msg)}`, "_blank");
}

function submitContest(){
  const selectedPrice = document.getElementById("contestPackage").value;
  const pkg = packages.find(p => String(p.price) === String(selectedPrice));
  const serials = [...document.querySelectorAll(".contest-serial")].map(i => i.value.trim());

  if(serials.some(s => !s)){
    document.getElementById("contestResult").textContent = "يجب إدخال 4 أرقام تسلسلية من نفس فئة الكرت.";
    return;
  }

  const unique = new Set(serials);
  if(unique.size !== 4){
    document.getElementById("contestResult").textContent = "الأرقام التسلسلية يجب أن تكون مختلفة.";
    return;
  }

  const msg = `طلب كرت مجاني - مسابقة 4 والخامس مجاناً
الفئة: ${pkg.name} - ${pkg.data}
السيريالات:
1) ${serials[0]}
2) ${serials[1]}
3) ${serials[2]}
4) ${serials[3]}`;
  window.open(`https://wa.me/${ownerWhatsApp}?text=${encodeURIComponent(msg)}`, "_blank");
  document.getElementById("contestResult").textContent = "تم تجهيز الطلب عبر واتساب. يتم التحقق من السيريالات من النظام قبل منح الكرت.";
}

function submitAgent(){
  const largest = packages[packages.length - 1];
  const name = document.getElementById("agentName").value.trim();
  const phone = document.getElementById("agentPhone").value.trim();
  const s1 = document.getElementById("refSerial1").value.trim();
  const s2 = document.getElementById("refSerial2").value.trim();

  if(!name || !phone || !s1 || !s2){
    document.getElementById("agentResult").textContent = "أدخل الاسم ورقم الواتساب والسيريالين.";
    return;
  }
  if(s1 === s2){
    document.getElementById("agentResult").textContent = "لا يمكن استخدام نفس السيريال مرتين.";
    return;
  }

  const msg = `طلب انضمام وكيل للشبكة
الاسم: ${name}
رقم واتساب العميل: ${phone}
الاشتراك المطلوب للتحقق: ${largest.name} - ${largest.data}
سيريال الشخص الأول: ${s1}
سيريال الشخص الثاني: ${s2}
المطلوب: اشتراك مجاني من نفس الفئة بعد التحقق.`;
  window.open(`https://wa.me/${ownerWhatsApp}?text=${encodeURIComponent(msg)}`, "_blank");
  document.getElementById("agentResult").textContent = "تم تجهيز طلب الوكيل عبر واتساب.";
}

renderPackages();
renderWallets();
renderStores();
